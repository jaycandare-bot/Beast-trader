/// Hybrid ICT decision engine for Delta ICT Terminal.
/// This module is deliberately signal-only: it never submits live orders.
import 'dart:math';
import 'delta_ict_service.dart';

enum HybridStyle { scalp, intraday }
enum MarketRegime { trending, ranging, volatile, unavailable }

class RiskConfig {
  final double riskPct; // percent of equity, e.g. 0.5 means 0.5%
  final double maxDailyLossPct;
  final double maxNotionalLeverage;
  final double feePctPerSide;
  final double slippagePctPerSide;
  final int maxOpenPositions;
  const RiskConfig({
    this.riskPct = 0.5,
    this.maxDailyLossPct = 2.0,
    this.maxNotionalLeverage = 2.0,
    this.feePctPerSide = 0.05,
    this.slippagePctPerSide = 0.03,
    this.maxOpenPositions = 2,
  });
}

class RiskSizing {
  final bool allowed;
  final String reason;
  final double riskUsd;
  final double stopDistance;
  final double quantity;
  final double notionalUsd;
  final double marginRequiredUsd;
  const RiskSizing({required this.allowed, required this.reason, this.riskUsd = 0, this.stopDistance = 0, this.quantity = 0, this.notionalUsd = 0, this.marginRequiredUsd = 0});
}

class HybridSignal {
  final String symbol;
  final String direction;
  final HybridStyle style;
  final MarketRegime regime;
  final int score;
  final double entry;
  final double stopLoss;
  final double target1;
  final double target2;
  final double atr;
  final List<String> confirmations;
  final List<String> warnings;
  const HybridSignal({required this.symbol, required this.direction, required this.style, required this.regime, required this.score, required this.entry, required this.stopLoss, required this.target1, required this.target2, required this.atr, required this.confirmations, required this.warnings});
  double get riskDistance => (entry - stopLoss).abs();
  double get rewardRisk => riskDistance > 0 ? (target2 - entry).abs() / riskDistance : 0;
}

class WalkForwardFold {
  final int trainStart, trainEnd, testStart, testEnd;
  final int trades, wins, losses;
  final double netR, profitFactor, winRatePct, maxDrawdownR, grossWinR, grossLossR;
  const WalkForwardFold({required this.trainStart, required this.trainEnd, required this.testStart, required this.testEnd, required this.trades, required this.wins, required this.losses, required this.netR, required this.profitFactor, required this.winRatePct, required this.maxDrawdownR, required this.grossWinR, required this.grossLossR});
}

class WalkForwardReport {
  final List<WalkForwardFold> folds;
  final int trades, wins, losses;
  final double netR, profitFactor, winRatePct, maxDrawdownR;
  final String note;
  const WalkForwardReport({required this.folds, required this.trades, required this.wins, required this.losses, required this.netR, required this.profitFactor, required this.winRatePct, required this.maxDrawdownR, required this.note});
}

class HybridStrategyEngine {
  final RiskConfig risk;
  const HybridStrategyEngine({this.risk = const RiskConfig()});

  /// Chooses the current regime from recent candles. Missing history is unavailable,
  /// never replaced by synthetic values.
  MarketRegime detectRegime(List<Candle> candles) {
    if (candles.length < 30) return MarketRegime.unavailable;
    final atr = _atr(candles, 14);
    if (atr <= 0 || candles.last.close <= 0) return MarketRegime.unavailable;
    final atrPct = atr / candles.last.close * 100;
    final move = (candles.last.close - candles[candles.length - 21].close).abs();
    final path = _pathLength(candles.sublist(candles.length - 21));
    final efficiency = path > 0 ? move / path : 0.0;
    if (atrPct >= 2.5) return MarketRegime.volatile;
    if (efficiency >= 0.42) return MarketRegime.trending;
    return MarketRegime.ranging;
  }

  /// Multi-timeframe setup. For intraday, 4h defines directional context, 1h
  /// confirms structure and 15m triggers. For scalp, 1h context, 15m structure,
  /// and 5m trigger are required. Pass only closed candles to avoid look-ahead.
  HybridSignal? generateSignal({
    required String symbol,
    required HybridStyle style,
    required List<Candle> triggerCandles,
    required List<Candle> structureCandles,
    required List<Candle> contextCandles,
  }) {
    final minTrigger = style == HybridStyle.scalp ? 45 : 35;
    if (triggerCandles.length < minTrigger || structureCandles.length < 30 || contextCandles.length < 30) return null;
    final regime = detectRegime(triggerCandles);
    if (regime == MarketRegime.unavailable || regime == MarketRegime.volatile) return null;
    final context = _bias(contextCandles);
    final structure = _bias(structureCandles);
    if (context == 0 || structure == 0 || context != structure) return null;

    final trigger = triggerCandles;
    final last = trigger.last;
    final previous = trigger[trigger.length - 2];
    final atr = _atr(trigger, 14);
    if (atr <= 0 || last.close <= 0) return null;
    final direction = context > 0 ? 'LONG' : 'SHORT';
    final recent = trigger.sublist(max(0, trigger.length - 22), trigger.length - 2);
    final priorHigh = recent.map((c) => c.high).reduce((a, b) => a > b ? a : b);
    final priorLow = recent.map((c) => c.low).reduce((a, b) => a < b ? a : b);
    final sweptLow = previous.low < priorLow && last.close > priorLow && last.close > last.open;
    final sweptHigh = previous.high > priorHigh && last.close < priorHigh && last.close < last.open;
    final bullishDisplacement = last.close > last.open && last.bodySize >= atr * (style == HybridStyle.scalp ? 0.65 : 0.8);
    final bearishDisplacement = last.close < last.open && last.bodySize >= atr * (style == HybridStyle.scalp ? 0.65 : 0.8);
    final bullishFvg = trigger.length >= 3 && last.low > trigger[trigger.length - 3].high;
    final bearishFvg = trigger.length >= 3 && last.high < trigger[trigger.length - 3].low;
    final emaFast = _ema(trigger, 9);
    final emaSlow = _ema(trigger, 21);
    final emaAligned = context > 0 ? emaFast > emaSlow : emaFast < emaSlow;

    final confirms = <String>[];
    confirms.add(style == HybridStyle.scalp ? '1H context + 15m structure' : '4H context + 1H structure');
    confirms.add(regime == MarketRegime.trending ? 'Trending regime' : 'Range regime: require sweep');
    if (emaAligned) confirms.add('Trigger EMA alignment');
    if (context > 0 ? sweptLow : sweptHigh) confirms.add('Liquidity sweep + reclaim');
    if (context > 0 ? bullishDisplacement : bearishDisplacement) confirms.add('Displacement candle');
    if (context > 0 ? bullishFvg : bearishFvg) confirms.add('3-candle FVG');

    // Require directional alignment, displacement and at least one structural event.
    final sweep = context > 0 ? sweptLow : sweptHigh;
    final displacement = context > 0 ? bullishDisplacement : bearishDisplacement;
    final fvg = context > 0 ? bullishFvg : bearishFvg;
    if (!displacement || (!sweep && !fvg) || !emaAligned) return null;
    if (regime == MarketRegime.ranging && !sweep) return null;
    final score = min(100, 45 + (context == structure ? 15 : 0) + (emaAligned ? 10 : 0) + (sweep ? 20 : 0) + (displacement ? 10 : 0) + (fvg ? 10 : 0));
    if (score < (style == HybridStyle.scalp ? 80 : 75)) return null;
    final entry = last.close;
    final stopDistance = max(atr * (style == HybridStyle.scalp ? 1.25 : 1.6), entry * 0.001);
    final sl = entry - context * stopDistance;
    final t1 = entry + context * stopDistance * 1.0;
    final t2 = entry + context * stopDistance * (style == HybridStyle.scalp ? 1.8 : 2.2);
    return HybridSignal(symbol: symbol, direction: direction, style: style, regime: regime, score: score, entry: entry, stopLoss: sl, target1: t1, target2: t2, atr: atr, confirmations: confirms, warnings: const ['Rule-based score is not a win probability.', 'Paper test before any live execution.']);
  }

  RiskSizing sizePosition({required double equityUsd, required double entry, required double stopLoss, int openPositions = 0, double dailyLossPct = 0, double leverage = 1}) {
    if (equityUsd <= 0 || entry <= 0 || stopLoss <= 0 || entry == stopLoss) return const RiskSizing(allowed: false, reason: 'Invalid equity, entry or stop-loss.');
    if (openPositions >= risk.maxOpenPositions) return const RiskSizing(allowed: false, reason: 'Maximum open positions reached.');
    if (dailyLossPct >= risk.maxDailyLossPct) return const RiskSizing(allowed: false, reason: 'Daily loss limit reached; trading disabled.');
    if (leverage <= 0 || leverage > risk.maxNotionalLeverage) return const RiskSizing(allowed: false, reason: 'Requested leverage exceeds configured cap.');
    final stopPct = (entry - stopLoss).abs() / entry;
    if (stopPct <= 0 || stopPct >= 0.25) return const RiskSizing(allowed: false, reason: 'Stop distance is invalid or too wide.');
    final riskUsd = equityUsd * (risk.riskPct / 100);
    // Approximate round-trip costs are included in per-unit risk, conservatively.
    final costPct = 2 * (risk.feePctPerSide + risk.slippagePctPerSide) / 100;
    final perUnitRisk = (entry - stopLoss).abs() + entry * costPct;
    final qtyByRisk = riskUsd / perUnitRisk;
    final maxNotional = equityUsd * min(leverage, risk.maxNotionalLeverage);
    final qtyByNotional = maxNotional / entry;
    final qty = min(qtyByRisk, qtyByNotional);
    if (!qty.isFinite || qty <= 0) return const RiskSizing(allowed: false, reason: 'Position sizing produced no valid quantity.');
    final notional = qty * entry;
    return RiskSizing(allowed: true, reason: 'Risk-capped sizing; estimated costs included.', riskUsd: riskUsd, stopDistance: (entry - stopLoss).abs(), quantity: qty, notionalUsd: notional, marginRequiredUsd: notional / leverage);
  }

  /// Expanding-window walk-forward evaluation. Each fold's test segment is strictly
  /// after its training segment. Parameters are fixed (not optimized on test data).
  /// A trade enters at the next candle open, uses stop-first ambiguity handling,
  /// and is charged estimated fees/slippage. This is a simple OHLC model, not fills.
  WalkForwardReport walkForwardBacktest({required List<Candle> candles, int folds = 5, int horizonBars = 12, double feeAndSlippagePctRoundTrip = 0.16}) {
    final sorted = [...candles]..sort((a, b) => a.timestamp.compareTo(b.timestamp));
    if (sorted.length < 180 || folds < 2) return const WalkForwardReport(folds: [], trades: 0, wins: 0, losses: 0, netR: 0, profitFactor: 0, winRatePct: 0, maxDrawdownR: 0, note: 'Insufficient data: provide at least 180 ordered candles and 2 folds.');
    final warmup = max(60, sorted.length ~/ (folds + 2));
    final testSize = (sorted.length - warmup) ~/ folds;
    if (testSize < 10) return const WalkForwardReport(folds: [], trades: 0, wins: 0, losses: 0, netR: 0, profitFactor: 0, winRatePct: 0, maxDrawdownR: 0, note: 'Insufficient test bars per fold.');
    final out = <WalkForwardFold>[];
    for (var f = 0; f < folds; f++) {
      final testStart = warmup + f * testSize;
      final testEnd = f == folds - 1 ? sorted.length : min(sorted.length, testStart + testSize);
      var wins = 0, losses = 0;
      var net = 0.0, peak = 0.0, maxDd = 0.0, winR = 0.0, lossR = 0.0;
      var i = testStart;
      while (i < testEnd - horizonBars - 2) {
        final history = sorted.sublist(0, i);
        final regime = detectRegime(history);
        if (regime == MarketRegime.unavailable || regime == MarketRegime.volatile) { i++; continue; }
        final bias = _bias(history);
        final atr = _atr(history, 14);
        if (bias == 0 || atr <= 0) { i++; continue; }
        final last = history.last;
        final prior = history.sublist(max(0, history.length - 21), history.length - 1);
        final hi = prior.map((c) => c.high).reduce((a, b) => a > b ? a : b);
        final lo = prior.map((c) => c.low).reduce((a, b) => a < b ? a : b);
        final sweep = bias > 0 ? (last.low < lo && last.close > lo) : (last.high > hi && last.close < hi);
        final displacement = bias > 0 ? (last.close > last.open && last.bodySize >= atr * 0.7) : (last.close < last.open && last.bodySize >= atr * 0.7);
        final fvg = bias > 0 ? last.low > history[history.length - 3].high : last.high < history[history.length - 3].low;
        final ef = _ema(history, 9), es = _ema(history, 21);
        if (!displacement || (!sweep && !fvg) || (bias > 0 ? ef <= es : ef >= es)) { i++; continue; }
        final entry = sorted[i + 1].open;
        final stopDistance = max(atr * 1.5, entry * 0.001);
        final sl = entry - bias * stopDistance;
        final target = entry + bias * stopDistance * 2.0;
        var resultR = 0.0;
        var closed = false;
        for (var j = i + 1; j <= min(i + horizonBars, testEnd - 1); j++) {
          final c = sorted[j];
          final stopHit = bias > 0 ? c.low <= sl : c.high >= sl;
          final targetHit = bias > 0 ? c.high >= target : c.low <= target;
          if (stopHit) { resultR = -1; closed = true; break; } // stop first if both touched
          if (targetHit) { resultR = 2; closed = true; break; }
        }
        if (!closed) {
          final exit = sorted[min(i + horizonBars, testEnd - 1)].close;
          resultR = ((exit - entry) * bias) / stopDistance;
          resultR = resultR.clamp(-1.0, 2.0).toDouble();
        }
        final costR = (entry * feeAndSlippagePctRoundTrip / 100) / stopDistance;
        resultR -= costR;
        if (resultR > 0) { wins++; winR += resultR; } else { losses++; lossR += resultR.abs(); }
        net += resultR;
        peak = max(peak, net);
        maxDd = max(maxDd, peak - net);
        i += max(1, horizonBars ~/ 2); // avoid highly overlapping trades
      }
      final total = wins + losses;
      out.add(WalkForwardFold(trainStart: 0, trainEnd: testStart, testStart: testStart, testEnd: testEnd, trades: total, wins: wins, losses: losses, netR: net, profitFactor: lossR > 0 ? winR / lossR : 0, winRatePct: total > 0 ? wins / total * 100 : 0, maxDrawdownR: maxDd, grossWinR: winR, grossLossR: lossR));
    }
    final trades = out.fold<int>(0, (a, b) => a + b.trades);
    final wins = out.fold<int>(0, (a, b) => a + b.wins);
    final losses = out.fold<int>(0, (a, b) => a + b.losses);
    final net = out.fold<double>(0, (a, b) => a + b.netR);
    final totalWinR = out.fold<double>(0, (a, b) => a + b.grossWinR);
    final totalLossR = out.fold<double>(0, (a, b) => a + b.grossLossR);
    final peakDd = out.fold<double>(0, (a, b) => max(a, b.maxDrawdownR));
    return WalkForwardReport(folds: out, trades: trades, wins: wins, losses: losses, netR: net, profitFactor: totalLossR > 0 ? totalWinR / totalLossR : 0, winRatePct: trades > 0 ? wins / trades * 100 : 0, maxDrawdownR: peakDd, note: 'Out-of-sample test folds only; fixed rules, OHLC assumptions, and estimated costs. Not a guarantee of live performance.');
  }

  double _pathLength(List<Candle> c) { var sum = 0.0; for (var i = 1; i < c.length; i++) { sum += (c[i].close - c[i - 1].close).abs(); } return sum; }
  double _ema(List<Candle> c, int period) { if (c.isEmpty) return 0; final k = 2 / (period + 1); var v = c.first.close; for (final x in c.skip(1)) { v = x.close * k + v * (1 - k); } return v; }
  int _bias(List<Candle> c) { if (c.length < 25) return 0; final e9 = _ema(c, 9), e21 = _ema(c, 21); final recent = c.sublist(max(0, c.length - 12)); final old = c[max(0, c.length - 12)].close; if (e9 > e21 && c.last.close > e21 && c.last.close >= old) return 1; if (e9 < e21 && c.last.close < e21 && c.last.close <= old) return -1; return 0; }
  double _atr(List<Candle> c, int period) { if (c.length < period + 1) return 0; final start = c.length - period; var sum = 0.0; for (var i = start; i < c.length; i++) { final x = c[i], prev = c[i - 1]; sum += max(x.high - x.low, max((x.high - prev.close).abs(), (x.low - prev.close).abs())); } return sum / period; }
}
