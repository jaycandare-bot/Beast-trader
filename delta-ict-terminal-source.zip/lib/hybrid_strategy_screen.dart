import 'package:flutter/material.dart';
import 'delta_ict_service.dart';
import 'hybrid_strategy_engine.dart';

class HybridStrategyScreen extends StatefulWidget {
  final DeltaExchangeIctService service;
  const HybridStrategyScreen({super.key, required this.service});
  @override
  State<HybridStrategyScreen> createState() => _HybridStrategyScreenState();
}

class _HybridStrategyScreenState extends State<HybridStrategyScreen> {
  final _symbolController = TextEditingController(text: 'BTCUSD');
  final _equityController = TextEditingController(text: '190');
  final _engine = const HybridStrategyEngine();
  HybridSignal? _scalpSignal;
  HybridSignal? _intradaySignal;
  WalkForwardReport? _report;
  RiskSizing? _sizing;
  bool _busy = false;
  String _status = 'Paper-analysis mode. No live orders are sent.';
  final Color _bg = const Color(0xFF0A0E14);
  final Color _card = const Color(0xFF121926);
  final Color _green = const Color(0xFF00E676);

  Future<void> _runAnalysis() async {
    final symbol = _symbolController.text.trim().toUpperCase();
    final equity = double.tryParse(_equityController.text.trim()) ?? 0;
    if (symbol.isEmpty || equity <= 0) {
      setState(() => _status = 'Enter a valid Delta Exchange symbol and positive paper equity.');
      return;
    }
    setState(() { _busy = true; _status = 'Fetching closed-candle history…'; });
    try {
      // Delta Exchange resolution names used by the existing service.
      final data = await Future.wait([
        widget.service.fetchCandles(symbol, resolution: '5m', count: 500),
        widget.service.fetchCandles(symbol, resolution: '15m', count: 500),
        widget.service.fetchCandles(symbol, resolution: '1h', count: 500),
        widget.service.fetchCandles(symbol, resolution: '4h', count: 500),
      ]);
      final five = data[0], fifteen = data[1], oneHour = data[2], fourHour = data[3];
      final scalp = _engine.generateSignal(symbol: symbol, style: HybridStyle.scalp, triggerCandles: five, structureCandles: fifteen, contextCandles: oneHour);
      final intraday = _engine.generateSignal(symbol: symbol, style: HybridStyle.intraday, triggerCandles: fifteen, structureCandles: oneHour, contextCandles: fourHour);
      final testData = _engine.walkForwardBacktest(candles: fifteen, folds: 5, horizonBars: 12);
      final selected = intraday ?? scalp;
      final sizing = selected == null ? null : _engine.sizePosition(equityUsd: equity, entry: selected.entry, stopLoss: selected.stopLoss, leverage: 1);
      if (!mounted) return;
      setState(() {
        _scalpSignal = scalp;
        _intradaySignal = intraday;
        _report = testData;
        _sizing = sizing;
        _status = 'Updated ${DateTime.now().toLocal().toString().substring(0, 19)}. Signal results require paper validation.';
      });
    } catch (e) {
      if (mounted) setState(() => _status = 'Analysis failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() { _symbolController.dispose(); _equityController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: _bg,
    body: ListView(padding: const EdgeInsets.all(14), children: [
      _header(), const SizedBox(height: 12),
      _panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('HYBRID STRATEGY LAB', style: TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.bold, letterSpacing: 1)),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: _field(_symbolController, 'Delta symbol', 'BTCUSD')), const SizedBox(width: 10), Expanded(child: _field(_equityController, 'Paper equity (USD)', '190', numeric: true))]),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: _busy ? null : _runAnalysis, icon: Icon(_busy ? Icons.hourglass_top : Icons.analytics_outlined), label: Text(_busy ? 'ANALYSING…' : 'RUN MULTI-TIMEFRAME ANALYSIS')),
        const SizedBox(height: 8), Text(_status, style: const TextStyle(color: Colors.white54, fontSize: 11)),
      ])),
      const SizedBox(height: 12),
      _section('SCALPING • 5m trigger / 15m structure / 1h context', _scalpSignal),
      const SizedBox(height: 10),
      _section('INTRADAY • 15m trigger / 1h structure / 4h context', _intradaySignal),
      const SizedBox(height: 12),
      _riskPanel(),
      const SizedBox(height: 12),
      _backtestPanel(),
      const SizedBox(height: 12),
      _panel(const Text('Safety: this module is signal-only. It does not place live orders. Historical OHLC backtests cannot model queue position, latency, liquidations or actual exchange fills. Confirm fees and contract sizing for your product before using any live strategy.', style: TextStyle(color: Colors.amberAccent, fontSize: 11, height: 1.45))),
    ]),
  );

  Widget _header() => Row(children: [const Icon(Icons.shield_outlined, color: Colors.cyanAccent, size: 27), const SizedBox(width: 9), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('HYBRID ICT ENGINE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)), Text('Scalp + intraday • risk-capped • walk-forward', style: TextStyle(color: Colors.white54, fontSize: 11))])), Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5), decoration: BoxDecoration(color: Colors.amber.withOpacity(.12), borderRadius: BorderRadius.circular(6)), child: const Text('PAPER ONLY', style: TextStyle(color: Colors.amberAccent, fontSize: 9, fontWeight: FontWeight.bold))]);
  Widget _field(TextEditingController c, String label, String hint, {bool numeric = false}) => TextField(controller: c, keyboardType: numeric ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text, style: const TextStyle(color: Colors.white, fontSize: 13), decoration: InputDecoration(labelText: label, hintText: hint, labelStyle: const TextStyle(color: Colors.white54, fontSize: 11), filled: true, fillColor: Colors.black26, border: OutlineInputBorder(borderRadius: BorderRadius.circular(7))));
  Widget _panel(Widget child) => Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(9), border: Border.all(color: Colors.white10)), child: child);
  Widget _section(String title, HybridSignal? s) => _panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.bold)), const SizedBox(height: 9), if (s == null) const Text('No qualified setup. Waiting is a valid signal.', style: TextStyle(color: Colors.white38, fontSize: 12)) else ...[
    Row(children: [Text('${s.direction}  ${s.score}/100', style: TextStyle(color: s.direction == 'LONG' ? _green : Colors.redAccent, fontWeight: FontWeight.w900, fontSize: 17)), const Spacer(), Text(s.regime.name.toUpperCase(), style: const TextStyle(color: Colors.cyanAccent, fontSize: 10))]),
    const SizedBox(height: 8), Text('Entry ${_price(s.entry)}   SL ${_price(s.stopLoss)}', style: const TextStyle(color: Colors.white, fontSize: 12)), Text('TP1 ${_price(s.target1)}   TP2 ${_price(s.target2)}   R:R ${s.rewardRisk.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white70, fontSize: 11)), const SizedBox(height: 7), ...s.confirmations.map((c) => Padding(padding: const EdgeInsets.only(bottom: 3), child: Text('✓ $c', style: const TextStyle(color: Colors.white60, fontSize: 10)))),
  ] ]));
  Widget _riskPanel() { final s = _sizing; return _panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('STRICT RISK SIZING', style: TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.bold, fontSize: 12)), const SizedBox(height: 7), const Text('Default risk: 0.5% equity per trade • daily loss stop: 2% • leverage cap: 2x • max open positions: 2', style: TextStyle(color: Colors.white60, fontSize: 11)), const SizedBox(height: 8), if (s == null) const Text('Sizing appears when a setup qualifies.', style: TextStyle(color: Colors.white38, fontSize: 11)) else Text(s.allowed ? 'Allowed • risk budget \$${s.riskUsd.toStringAsFixed(2)} • qty ${s.quantity.toStringAsFixed(6)} • notional \$${s.notionalUsd.toStringAsFixed(2)} • margin \$${s.marginRequiredUsd.toStringAsFixed(2)}' : 'BLOCKED • ${s.reason}', style: TextStyle(color: s.allowed ? _green : Colors.redAccent, fontSize: 11))])); }
  Widget _backtestPanel() { final r = _report; return _panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('15m WALK-FORWARD BACKTEST', style: TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.bold, fontSize: 12)), const SizedBox(height: 8), if (r == null) const Text('Run analysis to calculate out-of-sample results.', style: TextStyle(color: Colors.white38, fontSize: 11)) else ...[
    Wrap(spacing: 14, runSpacing: 8, children: [_metric('TEST TRADES', '${r.trades}'), _metric('WIN RATE', r.trades > 0 ? '${r.winRatePct.toStringAsFixed(1)}%' : 'N/A'), _metric('NET R', r.trades > 0 ? r.netR.toStringAsFixed(2) : 'N/A'), _metric('MAX DD', r.trades > 0 ? '${r.maxDrawdownR.toStringAsFixed(2)}R' : 'N/A')]), const SizedBox(height: 9), ...r.folds.map((f) => Text('Fold ${r.folds.indexOf(f) + 1}: ${f.trades} trades • ${f.winRatePct.toStringAsFixed(1)}% wins • ${f.netR.toStringAsFixed(2)}R net • PF ${f.trades > 0 ? f.profitFactor.toStringAsFixed(2) : 'N/A'}', style: const TextStyle(color: Colors.white60, fontSize: 10))), const SizedBox(height: 8), Text(r.note, style: const TextStyle(color: Colors.amberAccent, fontSize: 10, height: 1.4))
  ] ])); }
  Widget _metric(String label, String value) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: Colors.white38, fontSize: 9)), const SizedBox(height: 3), Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14))]);
  String _price(double p) => p >= 100 ? p.toStringAsFixed(2) : p >= 1 ? p.toStringAsFixed(4) : p.toStringAsFixed(6);
}
