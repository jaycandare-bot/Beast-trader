# Delta ICT Terminal v25 — Hybrid Strategy Lab

## What's new
- Added a **Hybrid Lab** tab to the existing terminal.
- Separate strategy profiles:
  - **Scalp:** 5m trigger, 15m structure, 1h context.
  - **Intraday:** 15m trigger, 1h structure, 4h context.
- Directional context agreement across timeframes is required.
- Added ATR-based regime classification; unavailable or highly volatile regimes are filtered instead of being filled with made-up values.
- Added trigger EMA alignment, liquidity sweep/reclaim, displacement and 3-candle FVG checks.
- Added risk-based sizing with 0.5% equity risk per trade, a 2% daily loss stop, 2x maximum leverage and two-position cap.
- Added expanding-window out-of-sample walk-forward reporting on 15m history, conservative stop-first handling when a candle touches both stop and target, and estimated fee/slippage costs.
- Added a visible paper-only warning. The new Hybrid Lab does not send live orders.

## Important limits
- This is a rule-based prototype, not an AI model or a guarantee of profitable signals. A score is a confluence score, **not** a probability of winning.
- The walk-forward test uses OHLC candles and fixed rules; it does not model order-book queue position, funding, liquidation, latency, exchange outages, or exact fill behavior. Configure costs for your actual Delta Exchange fee tier and instrument.
- For meaningful evaluation, export more history than the currently requested 500 candles per timeframe and test multiple market regimes. Do not optimize rules against the same out-of-sample period used to report results.
- The pre-existing Scanner and any legacy auto-trading controls are not converted into a verified live-safe execution system by this module. Keep live order execution disabled until separately audited.

## Build and verify
1. Extract this ZIP into a new folder; keep your original project as a backup.
2. Run `flutter pub get`.
3. Run `flutter analyze` and resolve any environment-specific warnings/errors.
4. Run `flutter test` if you add/maintain automated tests.
5. Launch the app and open **Hybrid Lab**. Test symbols supported by your Delta Exchange market-data endpoint.
6. Compare backtest results with a separate implementation before relying on them. No Flutter SDK was available in the generation environment, so this archive has not been compiled here.
